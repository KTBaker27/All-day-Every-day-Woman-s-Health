import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  base: '/All-day-Every-day-Woman-s-Health/',
  plugins: [react()]
})
